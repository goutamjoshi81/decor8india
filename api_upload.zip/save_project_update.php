<?php
// Decor8 India - Save/Update Project, Daily Site Updates & Documents to GoDaddy MySQL
require_once 'db_config.php';

try {
    $pdo = getDbConnection();
    $data = json_decode(file_get_contents("php://input"));

    if (empty($data->projectId)) {
        echo json_encode(["success" => false, "message" => "Project ID is required."]);
        exit();
    }

    $projectId = trim($data->projectId);

    // Auto-migrate projects table columns if missing
    try { $pdo->exec("ALTER TABLE projects ADD COLUMN client_email VARCHAR(120) DEFAULT NULL"); } catch (\PDOException $ex) {}
    try { $pdo->exec("ALTER TABLE projects ADD COLUMN work_updates_json LONGTEXT DEFAULT NULL"); } catch (\PDOException $ex) {}
    try { $pdo->exec("ALTER TABLE projects ADD COLUMN documents_json LONGTEXT DEFAULT NULL"); } catch (\PDOException $ex) {}
    try { $pdo->exec("ALTER TABLE projects ADD COLUMN payments_json LONGTEXT DEFAULT NULL"); } catch (\PDOException $ex) {}
    try { $pdo->exec("ALTER TABLE projects ADD COLUMN milestones_json LONGTEXT DEFAULT NULL"); } catch (\PDOException $ex) {}

    // 1. Fetch current project from DB
    $stmt = $pdo->prepare("SELECT * FROM projects WHERE id = ? LIMIT 1");
    $stmt->execute([$projectId]);
    $existing = $stmt->fetch();

    $workUpdates = !empty($existing['work_updates_json']) ? json_decode($existing['work_updates_json'], true) : [];
    $documents = !empty($existing['documents_json']) ? json_decode($existing['documents_json'], true) : [];
    $payments = !empty($existing['payments_json']) ? json_decode($existing['payments_json'], true) : [];

    if (!is_array($workUpdates)) $workUpdates = [];
    if (!is_array($documents)) $documents = [];
    if (!is_array($payments)) $payments = [];

    // Append new work update feed item if provided
    if (!empty($data->workUpdate)) {
        array_unshift($workUpdates, $data->workUpdate);
    }

    // Append new document if provided
    if (!empty($data->document)) {
        array_unshift($documents, $data->document);
    }

    // Append new payment milestone if provided
    if (!empty($data->payment)) {
        array_unshift($payments, $data->payment);
    }

    // Prepare fields to update
    $progressPercentage = isset($data->progressPercentage) ? (int)$data->progressPercentage : ($existing['progress_percentage'] ?? 0);
    $currentStage = !empty($data->currentStage) ? trim($data->currentStage) : ($existing['current_stage'] ?? 'Civil Work');
    $status = !empty($data->status) ? trim($data->status) : ($existing['status'] ?? 'Ongoing');

    $workUpdatesJson = json_encode($workUpdates);
    $documentsJson = json_encode($documents);
    $paymentsJson = json_encode($payments);

    if ($existing) {
        $updateStmt = $pdo->prepare("UPDATE projects SET 
            progress_percentage = ?, 
            current_stage = ?, 
            status = ?, 
            work_updates_json = ?, 
            documents_json = ?, 
            payments_json = ? 
            WHERE id = ?");
        $updateStmt->execute([
            $progressPercentage,
            $currentStage,
            $status,
            $workUpdatesJson,
            $documentsJson,
            $paymentsJson,
            $projectId
        ]);
    } else {
        $title = !empty($data->title) ? trim($data->title) : 'Bespoke Luxury Interior Project';
        $clientEmail = !empty($data->clientEmail) ? trim($data->clientEmail) : 'client@decor8india.com';
        $serviceType = !empty($data->serviceType) ? trim($data->serviceType) : 'Residential';
        $estimatedCost = !empty($data->estimatedCost) ? (float)$data->estimatedCost : 500000.00;

        $insertStmt = $pdo->prepare("INSERT INTO projects (id, title, client_id, client_email, service_type, estimated_cost, progress_percentage, current_stage, status, work_updates_json, documents_json, payments_json) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $insertStmt->execute([
            $projectId,
            $title,
            $clientEmail,
            $clientEmail,
            $serviceType,
            $estimatedCost,
            $progressPercentage,
            $currentStage,
            $status,
            $workUpdatesJson,
            $documentsJson,
            $paymentsJson
        ]);
    }

    echo json_encode([
        "success" => true,
        "message" => "Project synced successfully to GoDaddy MySQL!",
        "projectId" => $projectId
    ]);

} catch (Throwable $e) {
    echo json_encode([
        "success" => false,
        "message" => "Error syncing project update to database.",
        "error" => $e->getMessage()
    ]);
}
?>
